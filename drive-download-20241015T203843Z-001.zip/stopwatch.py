import RPi.GPIO as GPIO
import tm1637
import time

# Display Initialization
tm = tm1637.TM1637(clk=25 , dio=8)
tm.write([0,0,0,0])
# GPIO Initialization
GPIO.setmode(GPIO.BCM)
GPIO.setup(20, GPIO.IN)
GPIO.setup(21, GPIO.OUT)
GPIO.output(21, False)
# Main Loop
while True:
    # Do The Things If Button Pressed
    if not GPIO.input(20):
        sec = 0
        csec = 0
        press2 = False
        # Runs Inbetween The Button Presses
        while not (not GPIO.input(20) and press2):
            if GPIO.input(20):
                press2 = True
            GPIO.output(21,True)
            time.sleep(0.01) # stopwatch runs a bit slow but HYPOTHETICALLY THIS WORKS
            csec += 1
            if csec >= 100:
                csec = 0
                sec += 1
            if sec >= 60:
                sec = 0
            tm.numbers(sec, csec, colon=True)
        # After Button Re-pressed
        GPIO.output(21, False)
        tm.numbers(sec, csec, colon=True)
        while not GPIO.input(20):
            pass